from typing import List
from pydantic import BaseModel

class LocationsWithWeather(BaseModel):
    id: int
    name: str
    latitude: float
    longitude: float
    temperature: float
    rain: float
    wmoCode: int

class LocationCreate(BaseModel):
    name: str
    latitude: float
    longitude: float

class Location(LocationCreate):
    id: int

class LocationDetails(BaseModel):
    id: int
    name: str
    dates: List[str]
    maxTemps: List[float]
    minTemps: List[float]
    wmoCode: List[int]
