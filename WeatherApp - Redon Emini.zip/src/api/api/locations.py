from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from schemas.WeatherSchema import LocationsWithWeather, Location, LocationCreate, LocationDetails
from database import connection
from database.models import location
import httpx

router = APIRouter()

database = connection.get_db

api_url = "https://api.open-meteo.com/v1/forecast"

async def get_weather(lat, lng):
    params = {"latitude": lat, "longitude": lng, "daily": "temperature_2m_max,temperature_2m_min,weather_code"}

    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(api_url, params=params)
            response.raise_for_status()

        data = response.json()

        return data

    except httpx.HTTPStatusError as e:
        raise Exception(f"HTTP error occurred: {e}")

    except Exception as e:
        raise Exception(f"An error occurred: {e}")
    

async def get_current_weather(lat, lng):
    params = {"latitude": lat, "longitude": lng, "current": "temperature_2m,rain,weather_code"}
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(api_url, params=params)
            response.raise_for_status()

        data = response.json()
        current_data = data["current"]

        weather_data = {
            "temperature": current_data["temperature_2m"],
            "rain":  current_data["rain"],
            "wmo_code": current_data["weather_code"]
        }

        return weather_data

    except httpx.HTTPStatusError as e:
        raise Exception(f"HTTP error occurred: {e}")

    except Exception as e:
        raise Exception(f"An error occurred: {e}")

async def get_locations_weather(db):
    locations = db.query(location.Location).all()
    locations_with_weather = []

    for loc in locations:
        weather_data = await get_current_weather(loc.latitude, loc.longitude)
        location_with_weather = {
            "id": loc.id,
            "name": loc.name,
            "latitude": loc.latitude,
            "longitude": loc.longitude,
            "temperature": weather_data["temperature"],
            "rain": weather_data["rain"],
            "wmoCode": weather_data["wmo_code"]
        }
        locations_with_weather.append(location_with_weather)

    return locations_with_weather

@router.get("/locations", response_model=List[LocationsWithWeather])
async def get_locations_with_weather(db: Session = Depends(database)):
    return await get_locations_weather(db)

@router.post("/locations", response_model=LocationCreate)
async def create_location(location_data: LocationCreate, db: Session = Depends(database)):
    new_location = location.Location(name=location_data.name, latitude=location_data.latitude, longitude=location_data.longitude)
    db.add(new_location)
    db.commit()
    db.refresh(new_location)

    return new_location

@router.delete("/locations/{id}")
async def delete_location(id: int, db: Session = Depends(database)):
    location_to_delete = db.query(location.Location).filter(location.Location.id == id).first()

    if location_to_delete is None:
        raise HTTPException(status_code=404, detail="Location was not found")

    db.delete(location_to_delete)
    db.commit()

    return {"message": "Location deleted successfully"}

@router.get("/locations/{location_id}", response_model=LocationDetails)
async def get_location_with_weather(location_id: int, db: Session = Depends(database)):
    loc = db.query(location.Location).filter(location.Location.id == location_id).first()
    if not loc:
        raise HTTPException(status_code=404, detail="Location not found")

    weather_data = await get_weather(loc.latitude, loc.longitude)

    daily = weather_data["daily"]
    next_seven_days: List[str] = daily["time"]
    max_temps: List[float] = daily["temperature_2m_max"]
    min_temps: List[float] = daily["temperature_2m_min"]
    wmo_codes: List[int] = daily["weather_code"]

    location_with_weather = {
        "id": loc.id,
        "name": loc.name,
        "dates": next_seven_days,
        "maxTemps": max_temps,
        "minTemps": min_temps,
        "wmoCode": wmo_codes
    }

    return location_with_weather
