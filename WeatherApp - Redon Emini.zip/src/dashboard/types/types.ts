export type ButtonSize = '2xs' | 'xs' | 'sm' | 'md' | 'lg' | 'xl'

export type ButtonVariant = 'link' | 'solid' | 'outline' | 'soft' | 'ghost'

export type SidebarSide = 'right' | 'left'

export interface LocationsResponse {
    id: number;
    latitude: number;
    longitude: number;
    name: string;
    rain: number;
    temperature: number;
    wmoCode: number;
}

export type SelectedCityType = {
    Country: string;
    "Capital City": string;
    Latitude: number;
    Longitude: number;
    Population: number;
    "Capital Type": string;
}

export type CreateLocationsRequest = {
    name: string;
    latitude: number;
    longitude: number;
}

export type DeleteLocation = {
    id: number;
    name: string;
}

export type LocationDetailsType = {
    id: number;
    name: string;
    dates: string[];
    maxTemps: number[];
    minTemps: number[];
    wmoCode: number[];
    fetchedAt: string;
};