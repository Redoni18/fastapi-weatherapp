<template>
    <div class="app">
        <AppHeader />

        <div class="locations-table-container">
            <div class="table-header">
                <p class="table-header-title">Locations</p>
                <Button @submitEvent="toggleModalMethod" icon="i-heroicons-plus" buttonText="Add Location" buttonSize="xl" buttonVariant="solid" />
            </div>
            <UTable :ui="tableUI" :loading="loading" :columns="tableColumns" :rows="rows">
                <template #name-data="{ row }">
                    <div class="flex items-center gap-2">
                        <img alt="Weather Icon" :src="getWeatherIcon(row.wmoCode)" />
                        <span @click="fetchSingleLocation(row.id)" class="location-name">{{ row.name }}</span>
                    </div>
                </template>

                <template #temperature-data="{ row }">
                    <span>{{ row.temperature }}°C</span>
                </template>
            
                <template #rain-data="{ row }">
                    <span>{{ row.rain }}mm</span>
                </template>
            
                <template #actionButton-data="{ row }">
                    <Button @submitEvent="toggleConfirmationModal(row)" class="delete-button" buttonSize="xl" buttonVariant="ghost" icon="i-heroicons-trash" />
                </template>    
            </UTable>

            <div v-if="locations?.length && !loading" class="flex justify-end px-3 py-5">
                <UPagination v-model="page" :page-count="pageCount" :total="locations?.length" />
            </div>
        </div>

        <div>
            <Sidebar v-model="showSidebar" :sidebarOverlay="true">
                <template v-if="locationDetails && !sidebarLoading" #header>
                    <div class="header-container">
                        <h3 class="sidebar-title">{{ locationDetails.name }}</h3>
                        <UButton color="gray" variant="ghost" icon="i-heroicons-x-mark-20-solid" class="close-button" size="2xs" @click="closeSidebar" />
                    </div>
                </template>

                <template v-if="locationDetails && !sidebarLoading" #body>
                    <div class="weather-card-container">
                        <p class="text-stone-500">This Week:</p>
                        <WeatherCard v-for="(_, index) in 7" :key="new Date(locationDetails.dates[index])" :wmoCode="locationDetails.wmoCode[index]" :date="locationDetails.dates[index]" :maxTemp="locationDetails.maxTemps[index]" :minTemp="locationDetails.minTemps[index]" />
                    </div>
                </template>

                <template v-else #body>
                    <div class="sidebar-loading">
                        <p>Fetching weather information...</p>
                    </div>
                </template>

            </Sidebar>
        </div>

        

        <div>
            <Modal v-model="toggleModal">
                <template #header>
                    <div class="header-container">
                        <h3 class="modal-title">
                            Add Location
                        </h3>
                        <UButton color="gray" variant="ghost" icon="i-heroicons-x-mark-20-solid" class="close-button" size="2xs" @click="toggleModalMethod"/>
                    </div>
                </template>

                <template #body>
                    <div class="modal-body-container">
                        <InputMenu 
                            inputOptionAttribute="Capital City" 
                            :inputMenuOptions="CountryData" 
                            inputNullable="true" 
                            v-model="selectedCity" 
                            inputSize="xl" 
                            :inputSearchAttributes="['Capital City', 'Country']"
                        />
                        <Button 
                            :buttonDisabled="!selectedCity" 
                            @submitEvent="addLocation" 
                            buttonText="Add Location" 
                            buttonSize="xl" 
                            buttonVariant="solid" 
                            class="mt-2 w-full flex justify-center"
                        />
                    </div>
                </template>
            </Modal>
        </div>

        <div>
            <Modal v-model="showConfirmModal">
                <template #header>
                    <div class="header-container">
                        <h3 class="modal-title">
                            Confirm
                        </h3>
                        <UButton color="gray" variant="ghost" icon="i-heroicons-x-mark-20-solid" class="close-button" size="2xs" @click="toggleModalMethod"/>
                    </div>
                </template>

                <template #body>
                    <div class="modal-body-container">
                        <span>
                            Are you sure you want to delete location {{ locationToDelete?.name }}?
                        </span>

                        <div class="confirm-modal-buttons-container">
                            <Button 
                                v-if="locationToDelete"
                                @submitEvent="removeLocation(locationToDelete?.id)" 
                                buttonText="Confirm" 
                                buttonSize="xl" 
                                buttonVariant="solid" 
                                class="confirm-button"
                            />
                            <Button 
                                @submitEvent="closeDeleteModal" 
                                buttonText="Cancel" 
                                buttonSize="xl" 
                                buttonVariant="outline" 
                                class="cancel-button"
                            />
                        </div>
                    </div>
                </template>
            </Modal>
        </div>
    </div>
</template>

<script setup lang="ts">
import { CountryData } from "../data/CountryData"
import { createLocation, deleteLocation, fetchAllLocations, getLocation } from "../api/locations"
import { tableColumns, tableUI } from "../helpers/tableUtils"
import type { CreateLocationsRequest, LocationsResponse, DeleteLocation, SelectedCityType, LocationDetailsType } from "~/types/types";
import { getWeatherIcon } from "../helpers/tableUtils"

const selectedCity = ref<SelectedCityType | null>(null)
const locations =  ref<LocationsResponse[] | null>([])
const locationToDelete = ref<DeleteLocation>()
const locationDetails = ref<LocationDetailsType | null>(null)
const loading = ref<boolean>(true)
const sidebarLoading = ref<boolean>(true)

const toggleModal = ref<boolean>(false)
const showSidebar = ref<boolean>(false)
const showConfirmModal = ref<boolean>(false)

const page = ref(1)
const pageCount = 10

onMounted(() => {
    fetchLocations()
})

const rows = computed(() => {
  return locations.value?.slice((page.value - 1) * pageCount, (page.value) * pageCount)
})

const fetchLocations = async () => {
    try {
        const { data, pending } = await fetchAllLocations()
        locations.value = data
        loading.value = pending.value
    } catch (err) {
        console.error(err);
    }
}

const removeLocation = async (id: number) => {
    try {
        await deleteLocation(id)
        showConfirmModal.value = false
    } catch (err) {
        console.error(err);
    } finally {
        await fetchLocations()
    }
}

const addLocation = async () => {
    const locationBody: CreateLocationsRequest = {
        name: selectedCity.value?.["Capital City"] || '',
        latitude: selectedCity.value?.Latitude || 0,
        longitude: selectedCity.value?.Longitude || 0,
    };

    try {
        await createLocation(locationBody)
        toggleModal.value = false
    } catch (err) {
        console.error(err);
    } finally {
        await fetchLocations()
    }
}

const fetchSingleLocation = async (locationId: number) => {
    showSidebar.value = true
    try {
        locationDetails.value = null;
        const { data, pending } = await getLocation(locationId)
        locationDetails.value = data
        sidebarLoading.value = pending.value
    } catch (err) {
        console.log(err)
    }
}


const toggleModalMethod = () => {
    toggleModal.value = !toggleModal.value
    selectedCity.value = null
}

const closeSidebar = () => {
    showSidebar.value = false
}

const toggleConfirmationModal = (row: LocationsResponse) => {
    showConfirmModal.value = true
    locationToDelete.value = {
        id: row.id,
        name: row.name
    }
}

const closeDeleteModal = () => {
    showConfirmModal.value = false
}


</script>

<style scoped lang="postcss">

.app {
    @apply px-8 sm:px-16 lg:px-32;
}

.locations-table-container {
    @apply mt-10;
}

.table-header {
    @apply flex justify-between items-center mb-6;
}

.table-header-title {
    @apply text-4xl font-semibold;
}

.header-container {
    @apply flex items-center justify-between;
}

.modal-title {
    @apply text-2xl font-medium leading-6 text-gray-900 dark:text-white;
}

.sidebar-title {
    @apply text-3xl font-semibold leading-6 text-gray-900 dark:text-white;
}

.close-button {
    @apply -my-1 bg-gray-500/50;
}

.modal-body-container {
    @apply flex flex-col gap-1;
}

.delete-button {
    @apply bg-transparent hover:bg-transparent hover:text-slate-50 text-gray-500 p-2 flex ml-auto;
}

.location-name {
    @apply hover:text-slate-50 cursor-pointer;
}

.confirm-modal-buttons-container {
    @apply flex gap-2 items-center justify-center mt-4
}

.confirm-button {
    @apply flex-1 flex justify-center hover:text-white;
}

.cancel-button {
    @apply flex-1 flex justify-center bg-transparent !ring-red-500 hover:bg-red-400 text-red-500 dark:hover:text-slate-50
}

.weather-card-container {
    @apply flex flex-col gap-4
}


.sidebar-loading {
    @apply w-full h-full;
}
.sidebar-loading p {
    @apply text-center flex justify-center items-center font-semibold text-3xl
}

</style>
