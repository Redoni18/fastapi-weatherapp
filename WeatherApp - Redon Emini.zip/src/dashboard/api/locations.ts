import { useFetch } from "#app"
import { useAPIFetch } from "~/composables/useAPIFetch"
import type { CreateLocationsRequest, LocationsResponse } from "~/types/types"

const nuxtApp = useNuxtApp()
export const fetchAllLocations = async () => {
    try {
        const { data: locations, pending } = await useAPIFetch<LocationsResponse[]>("/locations")
        return {
            data: locations.value,
            pending,
        }
    } catch (error) {
        console.error("Error fetching locations:", error);
        throw error;
    }
}

export const deleteLocation = async (locationId: number) => {
    try {
        await useAPIFetch(`/locations/${locationId}`, {
            method: "DELETE"
        });
    } catch (error) {
        console.error("Error deleting location:", error);
        throw error;
    }
}

export const createLocation = async (location: CreateLocationsRequest) => {
    try {
        await useAPIFetch(`/locations`, {
            method: "POST",
            body: location
        });
    } catch (error) {
        console.error("Error deleting location:", error);
        throw error;
    }
}


export const getLocation = async (locationId: number) => {
    try {
        const { data: location, pending } = await useAPIFetch(`/locations/${locationId}`, {
            transform(input) {
                if (typeof input === 'object' && input !== null) {
                    return {
                        ...input,
                        fetchedAt: new Date()
                    };
                }

                return {
                    fetchedAt: new Date()
                }
            },
            getCachedData(key) {
                const data = nuxtApp.payload.data[key] || nuxtApp.static.data[key]

                if(!data) {
                    return
                }

                const expirationDate = new Date(data.fetchedAt)
                expirationDate.setTime(expirationDate.getTime() + 3600 * 1000)

                const isExpired = expirationDate.getTime() < Date.now()

                if(isExpired) return

                return data
            }
        });

        return {
            data: location.value,
            pending,
        }
    } catch (error) {
        console.error("Error deleting location:", error);
        throw error;
    }
}