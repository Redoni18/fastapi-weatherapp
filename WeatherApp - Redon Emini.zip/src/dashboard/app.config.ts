export default defineAppConfig({
    ui: {
        primary: 'blue',
    },
});
