import sunny from "@/assets/1.svg"
import thunderStorm from "@/assets/2.svg"
import partlyCloudy from "@/assets/3.svg"
import cloudy from "@/assets/4.svg"
import rainy from "@/assets/5.svg"

export const tableColumns = [{
    key: 'name',
    label: 'Location',
}, {
    key: 'temperature',
    label: 'Temperature'
}, {
    key: 'rain',
    label: 'Rainfall'
}, {
    key: 'actionButton',
}]
  
export const tableUI = {
    wrapper: "rounded-md",
    divide: "divide-y-0 divide-x-0",
    base: "max-h-[800px] overflow-y-auto dark:bg-stone-50",
    thead: "bg-stone-700",
    tbody: "divide-y divide-stone-700",
    tr: {
        base: "dark:bg-stone-50",
    }
}


export const getWeatherIcon = (wmoCode:number) => {
    if (wmoCode === 0 || wmoCode === 1) {
        return sunny
    } else if (wmoCode === 2) {
        return partlyCloudy
    } else if (wmoCode === 3 || wmoCode === 45 || wmoCode === 48) {
        return cloudy
    } else if (wmoCode === 51 || wmoCode === 53 || wmoCode === 55 || wmoCode === 61 || wmoCode === 63 || wmoCode === 80) {
        return rainy;
    } else if (wmoCode === 65 || (wmoCode >= 95 && wmoCode <= 99)) {
        return thunderStorm
    } else {
        return sunny;
    }
}