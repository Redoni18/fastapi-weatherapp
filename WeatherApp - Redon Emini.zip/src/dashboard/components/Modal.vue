<template>
    <UModal class="modal" :ui="modalUI" :fullscreen="modalProps.modalFullscreen" :overlay="modalProps.modalOverlay" :prevent-close="modalProps.preventClose">
        <header class="modal-header">
            <slot name="header" />
        </header>

        <main class="modal-body">
            <slot name="body" />
        </main>
    </UModal>
</template>

<script setup lang="ts">

const modalUI = {
    base: 'px-8 py-10 flex flex-col gap-5 box-border h-fit',
    overlay: {
        background: 'dark:bg-slate-600/50'
    },
    container: "items-center",
    background: 'dark:bg-zinc-900'
}

interface ModalProps {
    modalFullscreen?: boolean
    modalOverlay?: boolean
    preventClose?: boolean
}

const modalProps = withDefaults(defineProps<ModalProps>(), {
    modalFullscreen: false,
    modalOverlay: true,
    preventClose: false
})


</script>

<style scoped lang="postcss">
</style>