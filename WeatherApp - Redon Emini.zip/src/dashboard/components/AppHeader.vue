<template>
    <header class="app-header">
        <img width="50" alt="Header Logo" src="~/assets/3.svg" />
        <h1 class="header-title">Weather App</h1>
    </header>
</template>

<style scoped lang="postcss">
.app-header {
    @apply py-4 flex gap-2 items-center;
}
.header-title {
    @apply text-xl font-medium;
}
</style>