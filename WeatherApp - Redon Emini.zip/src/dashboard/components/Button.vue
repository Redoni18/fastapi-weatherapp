<template>
    <UButton 
        class="button-class"
        :class="buttonProps.customClass"
        dynamic 
        :icon="buttonProps.icon" 
        :variant="buttonProps.buttonVariant" 
        :size="buttonProps.buttonSize" 
        :label="buttonProps.buttonText" 
        @click="$emit('submitEvent')" 
        :trailing="buttonProps.iconTrailing"
        :disabled="buttonProps.buttonDisabled"
    />
</template>

<script setup lang="ts">
import { type ButtonSize, type ButtonVariant } from "@/types/types"

interface ButtonProps {
    buttonText?: string;
    buttonSize?: ButtonSize;
    buttonVariant?: ButtonVariant;
    icon?: string;
    iconTrailing?: boolean;
    customClass?: string;
    buttonDisabled?: boolean;
}

const buttonProps = withDefaults(defineProps<ButtonProps>(), {
  buttonSize: 'lg',
  buttonVariant: 'solid',
  iconTrailing: false,
  buttonDisabled: false
})

</script>

<style scoped lang="postcss">
.button-class {
    @apply font-semibold bg-blue-100;
}
</style>