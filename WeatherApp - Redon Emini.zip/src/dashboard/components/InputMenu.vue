<template>
    <UInputMenu 
        :search-attributes="inputSearchAttributes" 
        :option-attribute="inputOptionAttribute" 
        :value-attribute="inputValueAttribute" 
        :nullable="inputMenuProps.inputNullable" 
        :size="inputMenuProps.inputSize" 
        :options="inputMenuOptions" 
    />
</template>

<script setup lang="ts">
import type { ButtonSize } from '~/types/types';

interface InputMenuProps {
    inputMenuOptions: string[];
    inputSize?: ButtonSize;
    inputNullable?: boolean;
    inputValueAttribute?: string;
    inputOptionAttribute?: string;
    inputSearchAttributes?: string[];
}


const inputMenuProps = withDefaults(defineProps<InputMenuProps>(), {
  inputSize: 'lg',
  inputNullable: false
})
</script>