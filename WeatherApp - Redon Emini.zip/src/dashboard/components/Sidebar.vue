<template>
    <USlideover :ui="sidebarUi" :side="sidebarProps.sidebarSide" :overlay="sidebarProps.sidebarOverlay" :prevent-close="sidebarProps.preventClose">
        <header class="sidebar-header">
            <slot name="header" />
        </header>

        <main class="sidebar-body">
            <slot name="body" />
        </main>
    </USlideover>
</template>

<script setup lang="ts">
import type { PropType } from 'vue';
import type { SidebarSide } from '~/types/types';

const sidebarUi = {
    overlay: {
        background: 'dark:bg-slate-600/50'
    },
    background: 'dark:bg-zinc-900'
}

interface SidebarProps {
    sidebarSide?: string
    sidebarOverlay?: boolean
    preventClose?: boolean
}

const sidebarProps = withDefaults(defineProps<SidebarProps>(), {
    sidebarSide: 'right',
    sidebarOverlay: true,
    preventClose: false
})


</script>

<style scoped lang="postcss">
.sidebar-body,
.sidebar-header {
    @apply p-8 overflow-y-auto;
}
</style>