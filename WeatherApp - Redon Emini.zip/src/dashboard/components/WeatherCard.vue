<template>
    <div class="weather-card">
        <div class="icon-day-container" >
            <img class="weather-icon" alt="Weather Icon" :src="getWeatherIcon(cardProps.wmoCode)" />
            <p class="weekday-name">{{ day }}</p>
        </div>

        <div class="min-max-temp-container">
            <div class="min-temp-wrapper">
                <p class="temp-label">Min.</p>
                <span>{{ cardProps.minTemp }}°C</span>
            </div>
            <div class="max-temp-wrapper">
                <p class="temp-label">Max.</p>
                <span>{{ cardProps.maxTemp }}°C</span>
            </div>
        </div>
    </div>
</template>


<script setup lang="ts">
import { getWeatherIcon } from '~/helpers/tableUtils';

interface CardProps {
    date: string;
    wmoCode: number;
    minTemp: number;
    maxTemp: number;
}

const cardProps = defineProps<CardProps>()

const options: Intl.DateTimeFormatOptions = {
    weekday: 'long'
};

const day = computed(() => {
    const date = new Date(cardProps.date);
    return date.toLocaleDateString('en-US', options);
});

</script>

<style scoped lang="postcss">
.weather-card {
    @apply bg-stone-700 rounded-xl w-full h-fit py-6 px-5 flex justify-between;
}

.icon-day-container {
    @apply flex gap-2 items-center;
}

.min-max-temp-container {
    @apply flex flex-col gap-1 items-start justify-center min-w-fit w-24;
}

.min-temp-wrapper,
.max-temp-wrapper {
    @apply flex gap-4 justify-between w-full;
}

.temp-label {
    @apply text-left text-stone-500;
}

.weekday-name {
    @apply font-semibold text-3xl
}

.weather-icon {
    @apply w-16
}
</style>